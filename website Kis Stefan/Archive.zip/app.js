new fullpage('#fullpage', {
    autoScrolling: true,
    navigation: true
})